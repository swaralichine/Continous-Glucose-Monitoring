load("/Users/yash/Downloads/InsulinGlucoseData2.mat");
dateNumberNew = string(dateNumber);
numCGM = string(numCGM);
dateMuBolus = string(dateMuBolus);
actBolusDelivered = string(actBolusDelivered);

dateNumberNew = dateNumberNew';
numCGM = numCGM';
dateMuBolus = dateMuBolus';
actBolusDelivered = actBolusDelivered';

numCGM = flip(numCGM);
dateMuBolus = flip(dateMuBolus);
dateNumberNew = flip(dateNumberNew);
actBolusDelivered = flip(actBolusDelivered);

dateNumberNew(length(dateNumberNew)+1) = "dateNumber";

numCGM(length(numCGM)+1) = "numCGM";

dateMuBolus(length(dateMuBolus)+1) = "dateMuBolus";

actBolusDelivered(length(actBolusDelivered)+1) = "actBolusDelivered";

numCGM = flip(numCGM);
dateMuBolus = flip(dateMuBolus);
dateNumberNew = flip(dateNumberNew);
actBolusDelivered = flip(actBolusDelivered);

diff = length(numCGM) - length(actBolusDelivered);

for i = length(actBolusDelivered)+1:length(numCGM)
    dateMuBolus(i) = "NaN";
    actBolusDelivered(i) = "NaN";
end

diff = length(numCGM) - length(actBolusDelivered)


join = [actBolusDelivered dateMuBolus dateNumberNew numCGM];

writematrix(join, "datacgm2.csv");